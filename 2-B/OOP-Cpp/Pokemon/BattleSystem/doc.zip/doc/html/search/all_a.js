var searchData=
[
  ['json_0',['json',['../dd/d24/_pokemon_8h.html#ab701e3ac61a85b337ec5c1abaad6742d',1,'json:&#160;Pokemon.h'],['../d8/d09/_server_8h.html#ab701e3ac61a85b337ec5c1abaad6742d',1,'json:&#160;Server.h']]]
];
