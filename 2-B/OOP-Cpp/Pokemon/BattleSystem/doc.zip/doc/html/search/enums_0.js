var searchData=
[
  ['type_0',['Type',['../d7/dfa/class_pokemon.html#af46da7857346f8a2d4402adc4231d30d',1,'Pokemon']]]
];
