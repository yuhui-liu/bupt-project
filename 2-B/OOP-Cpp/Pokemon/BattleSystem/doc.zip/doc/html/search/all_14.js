var searchData=
[
  ['viewallonlineusers_0',['viewAllOnlineUsers',['../dc/db6/class_server.html#aa14b6c84f1a3f113be39cb91efa21629',1,'Server']]],
  ['viewalluserspokemons_1',['viewAllUsersPokemons',['../dc/db6/class_server.html#a446f0a55afbcc0e71b7fa4df82b5a0ef',1,'Server']]],
  ['viewmypokemons_2',['viewMyPokemons',['../dc/db6/class_server.html#a380db03f28a11309c6ebf84cee4430ce',1,'Server']]],
  ['viewwp_3',['viewWP',['../dc/db6/class_server.html#ac3b9594688dbfb22f09b614953bb7696',1,'Server']]]
];
