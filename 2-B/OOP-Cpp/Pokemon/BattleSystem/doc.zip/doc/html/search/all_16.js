var searchData=
[
  ['_7epokemon_0',['~Pokemon',['../d7/dfa/class_pokemon.html#ac0bffefc5936e50ca865c78ddd4dd118',1,'Pokemon']]],
  ['_7eserver_1',['~Server',['../dc/db6/class_server.html#ac0c2f1f04de64bd49ef343ca283e71ed',1,'Server']]]
];
