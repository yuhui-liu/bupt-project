var searchData=
[
  ['main_0',['main',['../df/d0a/main_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main.cpp']]],
  ['main_2ecpp_1',['main.cpp',['../df/d0a/main_8cpp.html',1,'']]],
  ['message_2',['message',['../d8/d1d/classmessage.html',1,'']]]
];
