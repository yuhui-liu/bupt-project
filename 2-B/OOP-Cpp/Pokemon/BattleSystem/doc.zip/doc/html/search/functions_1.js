var searchData=
[
  ['battle_0',['battle',['../d7/dfa/class_pokemon.html#a1af3a931a1210638bf66bca77798fe02',1,'Pokemon::battle()'],['../dc/db6/class_server.html#a2e07a3ac5c05e2d2068b3c2869143568',1,'Server::battle()']]]
];
