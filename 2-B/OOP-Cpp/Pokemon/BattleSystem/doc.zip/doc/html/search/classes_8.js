var searchData=
[
  ['tankpokemon_0',['TankPokemon',['../db/d22/class_tank_pokemon.html',1,'']]]
];
