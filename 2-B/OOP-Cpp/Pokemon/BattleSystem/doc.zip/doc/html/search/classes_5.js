var searchData=
[
  ['pokemon_0',['Pokemon',['../d7/dfa/class_pokemon.html',1,'']]],
  ['powerpokemon_1',['PowerPokemon',['../da/d25/class_power_pokemon.html',1,'']]]
];
