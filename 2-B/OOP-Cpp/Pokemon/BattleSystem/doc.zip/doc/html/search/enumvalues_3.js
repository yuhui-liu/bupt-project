var searchData=
[
  ['tank_0',['Tank',['../d7/dfa/class_pokemon.html#af46da7857346f8a2d4402adc4231d30dae4419464d570c4b497ba1979e790b104',1,'Pokemon']]]
];
