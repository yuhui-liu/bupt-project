var searchData=
[
  ['defaultpokemons_0',['defaultPokemons',['../dc/db6/class_server.html#a997400ef97bf1ea760a3124c1aa5d562',1,'Server']]],
  ['defensepower_1',['defensePower',['../d7/dfa/class_pokemon.html#af4469e3478b089f9f342e837cc208abe',1,'Pokemon']]]
];
