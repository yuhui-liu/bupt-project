var searchData=
[
  ['attackinterval_0',['attackInterval',['../d7/dfa/class_pokemon.html#af139c94cfd8d0756b1979e3f53fe7d11',1,'Pokemon']]],
  ['attackpower_1',['attackPower',['../d7/dfa/class_pokemon.html#af245403254be67c50737491b1a16ff49',1,'Pokemon']]]
];
