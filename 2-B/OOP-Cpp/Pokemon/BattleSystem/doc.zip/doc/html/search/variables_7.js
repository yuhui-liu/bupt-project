var searchData=
[
  ['level_0',['level',['../d7/dfa/class_pokemon.html#a9d568cb03ac0fe26fc7145ba5116f5f8',1,'Pokemon']]],
  ['levelexp_1',['levelExp',['../d7/dfa/class_pokemon.html#a0805e0b5da052f69d55f609e2b06c652',1,'Pokemon']]]
];
