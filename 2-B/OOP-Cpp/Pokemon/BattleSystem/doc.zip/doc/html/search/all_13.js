var searchData=
[
  ['userdata_0',['userData',['../dc/db6/class_server.html#ae5b452b06848054769ad86bb1fad3efb',1,'Server']]],
  ['username2pokemon_1',['username2pokemon',['../dc/db6/class_server.html#af8f7e98324fbc074ffcab6d836608392',1,'Server']]]
];
