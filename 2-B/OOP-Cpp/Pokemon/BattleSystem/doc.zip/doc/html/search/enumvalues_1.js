var searchData=
[
  ['defensive_0',['Defensive',['../d7/dfa/class_pokemon.html#af46da7857346f8a2d4402adc4231d30da3727b4d2311005c88de3b4a52f3de3a2',1,'Pokemon']]]
];
