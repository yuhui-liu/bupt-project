var searchData=
[
  ['agile_0',['Agile',['../d7/dfa/class_pokemon.html#af46da7857346f8a2d4402adc4231d30da657fd3eec6624217c3ad5de3744a69d2',1,'Pokemon']]]
];
