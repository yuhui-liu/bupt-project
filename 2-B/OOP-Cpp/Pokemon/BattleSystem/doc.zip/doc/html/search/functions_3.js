var searchData=
[
  ['defensivepokemon_0',['DefensivePokemon',['../dd/dfa/class_defensive_pokemon.html#aa61ff168456c053c301cc9473e3eed5c',1,'DefensivePokemon::DefensivePokemon(std::string, std::string)'],['../dd/dfa/class_defensive_pokemon.html#aea4d63c8fe3c2d4457ebd9b60c066c5b',1,'DefensivePokemon::DefensivePokemon(json j)']]]
];
