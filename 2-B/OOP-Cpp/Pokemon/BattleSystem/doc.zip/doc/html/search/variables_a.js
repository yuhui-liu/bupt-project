var searchData=
[
  ['skill_0',['skill',['../d7/dfa/class_pokemon.html#ac9985af5f4ab5a012d362846a57ecab4',1,'Pokemon']]],
  ['specialattack_1',['specialAttack',['../d7/dfa/class_pokemon.html#a19ac1496a1c32bbc761ea6d977bc5bb6',1,'Pokemon']]]
];
