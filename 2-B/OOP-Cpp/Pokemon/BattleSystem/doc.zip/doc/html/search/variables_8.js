var searchData=
[
  ['name_0',['name',['../d7/dfa/class_pokemon.html#acc4312e4350fe5e22408294becb77c2b',1,'Pokemon']]]
];
