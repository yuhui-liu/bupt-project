var searchData=
[
  ['defaultpokemons_0',['defaultPokemons',['../dc/db6/class_server.html#a997400ef97bf1ea760a3124c1aa5d562',1,'Server']]],
  ['defensepower_1',['defensePower',['../d7/dfa/class_pokemon.html#af4469e3478b089f9f342e837cc208abe',1,'Pokemon']]],
  ['defensive_2',['Defensive',['../d7/dfa/class_pokemon.html#af46da7857346f8a2d4402adc4231d30da3727b4d2311005c88de3b4a52f3de3a2',1,'Pokemon']]],
  ['defensivepokemon_3',['DefensivePokemon',['../dd/dfa/class_defensive_pokemon.html',1,'DefensivePokemon'],['../dd/dfa/class_defensive_pokemon.html#aa61ff168456c053c301cc9473e3eed5c',1,'DefensivePokemon::DefensivePokemon(std::string, std::string)'],['../dd/dfa/class_defensive_pokemon.html#aea4d63c8fe3c2d4457ebd9b60c066c5b',1,'DefensivePokemon::DefensivePokemon(json j)']]]
];
