var searchData=
[
  ['levelup_0',['levelUp',['../d7/dfa/class_pokemon.html#a1902298611439e21bd8fb7d91f2873e4',1,'Pokemon']]],
  ['login_1',['login',['../dc/db6/class_server.html#a25a7ebb7955181731377526d6f767c40',1,'Server']]],
  ['logout_2',['logout',['../dc/db6/class_server.html#a4e35ac8dcc13e8f79f81487f5d82e02f',1,'Server']]]
];
