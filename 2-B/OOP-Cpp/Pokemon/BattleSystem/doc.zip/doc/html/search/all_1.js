var searchData=
[
  ['_5fdisconnect_0',['_disconnect',['../dc/db6/class_server.html#a947fb8f2828a1cd57e68d0b628163e37',1,'Server']]],
  ['_5fduel_5fbattle_1',['_duel_battle',['../dc/db6/class_server.html#aaff01302d7279fc542dd5207d6af1218',1,'Server']]],
  ['_5flogin_2',['_login',['../dc/db6/class_server.html#addf0dbd0d0b2e1e584b372346e0084b9',1,'Server']]],
  ['_5flogout_3',['_logout',['../dc/db6/class_server.html#a57bca4db71a6acd490a8b0fddedaf6cd',1,'Server']]],
  ['_5fnormal_5fbattle_4',['_normal_battle',['../dc/db6/class_server.html#acb3006cc2ee7e29d36cdef575628382b',1,'Server']]],
  ['_5fregister_5',['_register',['../dc/db6/class_server.html#a03d80ec3b5bd3eb43e1bada116eec158',1,'Server']]],
  ['_5fview_5fmy_5fpokemons_6',['_view_my_pokemons',['../dc/db6/class_server.html#acbbcf5181da4bb24712d77710339f9ae',1,'Server']]],
  ['_5fview_5fpokemons_7',['_view_pokemons',['../dc/db6/class_server.html#ab47d791bbfe3f32f3a72d8f13d43ac43',1,'Server']]],
  ['_5fview_5fusers_8',['_view_users',['../dc/db6/class_server.html#ac335f219e123f798a7c4b97ee1b2259c',1,'Server']]],
  ['_5fview_5fwinning_5fpercentage_9',['_view_winning_percentage',['../dc/db6/class_server.html#a28537281f49a00e684d03a1946bec6f3',1,'Server']]]
];
