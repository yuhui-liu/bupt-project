var searchData=
[
  ['sleep_5fms_0',['sleep_ms',['../d8/d13/_server_8cpp.html#abbfe5149f45ec05c139066cdd89f9f32',1,'sleep_ms:&#160;Server.cpp'],['../d7/d40/_tools_8cpp.html#abbfe5149f45ec05c139066cdd89f9f32',1,'sleep_ms:&#160;Tools.cpp']]]
];
