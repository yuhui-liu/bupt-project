var searchData=
[
  ['tankpokemon_0',['TankPokemon',['../db/d22/class_tank_pokemon.html#ad68cd4a4836ba96e54dfac0ae40841bf',1,'TankPokemon::TankPokemon(std::string, std::string)'],['../db/d22/class_tank_pokemon.html#ad7577e003bddb96d18f56f11f174b180',1,'TankPokemon::TankPokemon(json j)']]],
  ['test_1',['test',['../d7/dfa/class_pokemon.html#ac51b19c76d597b6126312d22378d0067',1,'Pokemon']]]
];
