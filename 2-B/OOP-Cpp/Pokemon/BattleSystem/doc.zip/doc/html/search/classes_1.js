var searchData=
[
  ['defensivepokemon_0',['DefensivePokemon',['../dd/dfa/class_defensive_pokemon.html',1,'']]]
];
