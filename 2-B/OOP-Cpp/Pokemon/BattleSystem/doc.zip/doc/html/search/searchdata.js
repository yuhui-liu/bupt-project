var indexSectionsWithContent =
{
  0: "1_abcdefghjlmnoprstuvw~",
  1: "adfmnprst",
  2: "1mpst",
  3: "abcdglmprstvw~",
  4: "_acdefhlnostu",
  5: "js",
  6: "t",
  7: "adpt",
  8: "s",
  9: "b"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "pages"
};

var indexSectionLabels =
{
  0: "全部",
  1: "类",
  2: "文件",
  3: "函数",
  4: "变量",
  5: "类型定义",
  6: "枚举",
  7: "枚举值",
  8: "宏定义",
  9: "页"
};

