var searchData=
[
  ['experience_0',['experience',['../d7/dfa/class_pokemon.html#a8a810b447096373a5dc5e33af5801fbb',1,'Pokemon']]]
];
