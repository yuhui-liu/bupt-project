var searchData=
[
  ['socklen_5ft_0',['socklen_t',['../d8/d13/_server_8cpp.html#aaab2d2efbcdc91f56b16982a4f44c97f',1,'socklen_t:&#160;Server.cpp'],['../d7/d40/_tools_8cpp.html#a3f2ca33eef3be52c854e495ab78ec542',1,'socklen_t:&#160;Tools.cpp']]]
];
