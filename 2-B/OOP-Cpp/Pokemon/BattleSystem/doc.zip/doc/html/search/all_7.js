var searchData=
[
  ['fd2username_0',['fd2username',['../dc/db6/class_server.html#a251c7d3a7f18923b95aacff50694589a',1,'Server']]],
  ['file_1',['file',['../d7/dda/classfile.html',1,'']]],
  ['flag_2',['flag',['../dd/dfa/class_defensive_pokemon.html#a5cd9c550a8dbca73b170fa2d970d511c',1,'DefensivePokemon']]],
  ['fout_3',['fout',['../d7/dda/classfile.html#ac5584b8a33c755013167d995251e9d53',1,'file']]]
];
