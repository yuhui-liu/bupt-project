var searchData=
[
  ['type_0',['type',['../d7/dfa/class_pokemon.html#a6d79bb7ae538544d93e25d2472ad6f0d',1,'Pokemon']]]
];
