var searchData=
[
  ['back_5fto_5fcaller_0',['back_to_caller',['../d3/df7/class_battle_window.html#abf1cf00d624dfd69c9515ed7173982c5',1,'BattleWindow::back_to_caller'],['../d9/d90/class_second_window.html#a3a9d38b61e2e2128867d163d1f26ddd9',1,'SecondWindow::back_to_caller']]],
  ['buf_1',['buf',['../d3/d7a/class_client.html#a0e029ba89c5fc28538ee2697988bd7e0',1,'Client']]]
];
