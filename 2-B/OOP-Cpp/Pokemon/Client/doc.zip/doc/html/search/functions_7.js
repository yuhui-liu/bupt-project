var searchData=
[
  ['login_0',['login',['../d3/d7a/class_client.html#a278f4c3e6ab8f84a50ab617bb41e96bf',1,'Client']]],
  ['logout_1',['logout',['../d3/d7a/class_client.html#a2d288341722fcd28b27328dbd2cda120',1,'Client']]],
  ['losepokemon_2',['losePokemon',['../d3/d7a/class_client.html#a45a67610a08ee78d52a95ad5d3d284a9',1,'Client::losePokemon(const std::string &amp;) const'],['../d3/d7a/class_client.html#a4ec23721bda096774b47afd7f346a15c',1,'Client::losePokemon(int i) const']]],
  ['losewindow_3',['LoseWindow',['../da/d90/class_lose_window.html#a6d27ea56ae8eec031da297499b336877',1,'LoseWindow']]]
];
