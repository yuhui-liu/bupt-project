var searchData=
[
  ['i_0',['i',['../da/d90/class_lose_window.html#a791ce98cbdaa2cd6a57999796fd8dd72',1,'LoseWindow']]],
  ['isconnectedflag_1',['isConnectedFlag',['../d3/d7a/class_client.html#af35185dfffb30d5d98a8ec68794f1f8d',1,'Client']]],
  ['isduel_2',['isDuel',['../d3/df7/class_battle_window.html#a8b3bb8534c33a11867602ddd1b197015',1,'BattleWindow']]]
];
