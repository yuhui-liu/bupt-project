var searchData=
[
  ['viewallonlineusers_0',['viewAllOnlineUsers',['../d3/d7a/class_client.html#a0f4a339b083961d4545d0e5aca21e464',1,'Client']]],
  ['viewalluserspokemons_1',['viewAllUsersPokemons',['../d3/d7a/class_client.html#a4ebc1321c615924d69f84cae12f6ea47',1,'Client']]],
  ['viewmypokemons_2',['viewMyPokemons',['../d3/d7a/class_client.html#a2a657020b63b5938da6db70696c37bc0',1,'Client']]],
  ['viewmypokemonswindow_3',['ViewMyPokemonsWindow',['../dc/dd0/class_view_my_pokemons_window.html#a932f0e8d0b4b99f8f640f3ae1c9d4bab',1,'ViewMyPokemonsWindow']]],
  ['viewpokemonwindow_4',['ViewPokemonWindow',['../d4/d37/class_view_pokemon_window.html#ab6a229795eafa62ee1d91aff10907079',1,'ViewPokemonWindow']]],
  ['viewwp_5',['viewWP',['../d3/d7a/class_client.html#a48d79ec1ad5587f5b624276a28a34d7c',1,'Client']]]
];
