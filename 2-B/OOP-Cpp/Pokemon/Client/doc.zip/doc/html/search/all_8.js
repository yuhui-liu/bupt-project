var searchData=
[
  ['handler_0',['handler',['../da/d90/class_lose_window.html#a2f5b7b713141c1bf243d48300374b85e',1,'LoseWindow']]],
  ['highlevelnum_1',['highLevelNum',['../d3/d7a/class_client.html#a9a16c71a7db589e87c1ae6d9188ac8c0',1,'Client']]]
];
