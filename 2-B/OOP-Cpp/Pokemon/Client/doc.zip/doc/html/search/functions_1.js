var searchData=
[
  ['battle_0',['battle',['../d3/d7a/class_client.html#ae75cd22f38bcd061c00469fdf19c2ea5',1,'Client']]],
  ['battlewindow_1',['BattleWindow',['../d3/df7/class_battle_window.html#a0364bca11a1a712fea581bd5f3f3599c',1,'BattleWindow']]]
];
