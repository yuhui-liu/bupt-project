var searchData=
[
  ['isconnected_0',['isConnected',['../d3/d7a/class_client.html#adb70f8af5f71b5e09c4a0a8f6da3912c',1,'Client']]]
];
