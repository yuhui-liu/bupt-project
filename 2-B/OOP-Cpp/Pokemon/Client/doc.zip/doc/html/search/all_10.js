var searchData=
[
  ['recvfromserver_0',['recvFromServer',['../d3/d7a/class_client.html#a17912d03cc0cfdbb0b546dc467623e07',1,'Client']]],
  ['registeraccount_1',['registerAccount',['../d3/d7a/class_client.html#aa6b1b0f6d8faad082adef8f89e700f34',1,'Client']]],
  ['removepokemon_2',['removePokemon',['../d3/d7a/class_client.html#adc46b7d92a224e316a6fe22650a65672',1,'Client']]],
  ['result_3',['result',['../d3/df7/class_battle_window.html#aaa7eca30006a21bc6687d2911b177eb5',1,'BattleWindow']]]
];
