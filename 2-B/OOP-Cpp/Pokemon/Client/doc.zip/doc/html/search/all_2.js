var searchData=
[
  ['addpokemon_0',['addPokemon',['../d3/d7a/class_client.html#a828771117e3f9d54d6ec33a29c1ab6f7',1,'Client']]],
  ['appendmessage_1',['appendMessage',['../d9/dc6/class_main_window.html#a702234d1ed2bd6c63cb9a68aa14bddef',1,'MainWindow::appendMessage()'],['../d9/d90/class_second_window.html#a63a573484cd735661e42d5588f36dc78',1,'SecondWindow::appendMessage()']]]
];
