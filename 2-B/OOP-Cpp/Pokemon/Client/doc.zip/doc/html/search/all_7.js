var searchData=
[
  ['gethighlevelnum_0',['getHighLevelNum',['../d3/d7a/class_client.html#ab316a8b79102d2abddfcdf37cfeda02e',1,'Client']]],
  ['getmypokemons_1',['getMyPokemons',['../d3/d7a/class_client.html#a027651ef6c15f2904d040cf677ebfd18',1,'Client']]],
  ['getnewpokemon_2',['getNewPokemon',['../d3/d7a/class_client.html#a09f483ec32cfc2727e6be7658b0c30ee',1,'Client']]],
  ['getpic_3',['getPic',['../d3/d7a/class_client.html#af1d20a94e9b4ad333736a0cf8af296e0',1,'Client']]],
  ['getpokemonnum_4',['getPokemonNum',['../d3/d7a/class_client.html#a2fb43965649d2fa6f73b072ff47ad112',1,'Client']]]
];
