var searchData=
[
  ['_5fdisconnect_0',['_disconnect',['../d3/d7a/class_client.html#a0279ff202de998b7bb5ca96df213c1da',1,'Client']]],
  ['_5fduel_5fbattle_1',['_duel_battle',['../d3/d7a/class_client.html#acc6c75e18b5b6af823b0e6fdc292fc59',1,'Client']]],
  ['_5flogin_2',['_login',['../d3/d7a/class_client.html#abe78466d97ea80d1d5909fae8686bf2c',1,'Client']]],
  ['_5flogout_3',['_logout',['../d3/d7a/class_client.html#a970424036c9343e15d0f1ac995c7cdfe',1,'Client']]],
  ['_5fnormal_5fbattle_4',['_normal_battle',['../d3/d7a/class_client.html#a8c5c6eab0955330c8f1b2b3dc4a359f5',1,'Client']]],
  ['_5fregister_5',['_register',['../d3/d7a/class_client.html#a035e4b96b6e7aff5efaeb6accea78d8d',1,'Client']]],
  ['_5fview_5fmy_5fpokemons_6',['_view_my_pokemons',['../d3/d7a/class_client.html#af2fcca1cc1eccb50192756f50093684f',1,'Client']]],
  ['_5fview_5fpokemons_7',['_view_pokemons',['../d3/d7a/class_client.html#adb319b9aab918bf6f7c6c972d7cb8c98',1,'Client']]],
  ['_5fview_5fusers_8',['_view_users',['../d3/d7a/class_client.html#aac717ab065634c44a86586ef8082f4f7',1,'Client']]],
  ['_5fview_5fwinning_5fpercentage_9',['_view_winning_percentage',['../d3/d7a/class_client.html#ae94ae6d480f956870d71286b99360488',1,'Client']]]
];
